import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, FileText, Home, Calculator, Users, Phone, Shield, FileCode, BookOpen, Code } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { calculatorCategories } from '../data/calculatorData';

export const Sitemap: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <button 
          onClick={() => navigate(-1)} 
          className="flex items-center text-neutral-600 hover:text-neutral-900 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          <span>Back</span>
        </button>
      </div>
      
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-4">Sitemap</h1>
        <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
          A complete overview of all pages available on FinCalc India
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        <div className="bg-white rounded-xl shadow-md p-6 border border-neutral-200">
          <h2 className="text-xl font-semibold text-neutral-900 mb-4 flex items-center">
            <Home className="h-5 w-5 mr-2 text-primary-600" />
            Main Pages
          </h2>
          <ul className="space-y-2">
            <li>
              <Link to="/" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Home
              </Link>
            </li>
            <li>
              <Link to="/blog" className="text-neutral-700 hover:text-primary-600 transition-colors flex items-center">
                <FileText className="h-4 w-4 mr-1" />
                Blog
              </Link>
            </li>
            <li>
              <Link to="/about-us" className="text-neutral-700 hover:text-primary-600 transition-colors flex items-center">
                <Users className="h-4 w-4 mr-1" />
                About Us
              </Link>
            </li>
            <li>
              <Link to="/contact-us" className="text-neutral-700 hover:text-primary-600 transition-colors flex items-center">
                <Phone className="h-4 w-4 mr-1" />
                Contact Us
              </Link>
            </li>
            <li>
              <Link to="/privacy-policy" className="text-neutral-700 hover:text-primary-600 transition-colors flex items-center">
                <Shield className="h-4 w-4 mr-1" />
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link to="/terms-and-conditions" className="text-neutral-700 hover:text-primary-600 transition-colors flex items-center">
                <FileText className="h-4 w-4 mr-1" />
                Terms and Conditions
              </Link>
            </li>
            <li>
              <Link to="/sitemap" className="text-neutral-700 hover:text-primary-600 transition-colors flex items-center">
                <FileCode className="h-4 w-4 mr-1" />
                Sitemap
              </Link>
            </li>
          </ul>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 border border-neutral-200">
          <h2 className="text-xl font-semibold text-neutral-900 mb-4 flex items-center">
            <BookOpen className="h-5 w-5 mr-2 text-primary-600" />
            Special Pages
          </h2>
          <ul className="space-y-2">
            <li>
              <Link to="/financial-literacy-tool" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Financial Literacy & Debt Management Tool
              </Link>
            </li>
            <li>
              <Link to="/open-source-templates" className="text-neutral-700 hover:text-primary-600 transition-colors flex items-center">
                <Code className="h-4 w-4 mr-1" />
                Open Source Templates
              </Link>
            </li>
            <li>
              <Link to="/blog/write" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Write for Our Blog
              </Link>
            </li>
          </ul>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 border border-neutral-200 lg:col-span-1 md:col-span-2 lg:row-span-2">
          <h2 className="text-xl font-semibold text-neutral-900 mb-4 flex items-center">
            <Calculator className="h-5 w-5 mr-2 text-primary-600" />
            Popular Calculators
          </h2>
          <ul className="space-y-2">
            <li>
              <Link to="/calculators/emi-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                EMI Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/sip-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                SIP Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/income-tax-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Income Tax Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/ppf-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                PPF Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/gst-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                GST Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/home-loan-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Home Loan Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/retirement-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Retirement Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/compound-interest-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Compound Interest Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/fd-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Fixed Deposit Calculator
              </Link>
            </li>
            <li>
              <Link to="/calculators/human-life-value-calculator" className="text-neutral-700 hover:text-primary-600 transition-colors">
                Human Life Value Calculator
              </Link>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-8 border border-neutral-200 mb-12">
        <h2 className="text-2xl font-bold text-neutral-900 mb-6 text-center">All Calculators by Category</h2>
        
        <div className="space-y-8">
          {calculatorCategories.map(category => (
            <div key={category.id} className="border-b border-neutral-200 pb-6 last:border-b-0 last:pb-0">
              <h3 className="text-xl font-semibold text-neutral-900 mb-4" id={category.id}>
                {category.name}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {category.calculators.map(calculator => (
                  <Link 
                    key={calculator.id}
                    to={`/calculators/${calculator.id}`}
                    className="text-neutral-700 hover:text-primary-600 transition-colors text-sm py-1"
                  >
                    {calculator.name}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="bg-primary-50 rounded-xl p-6 border border-primary-100 text-center">
        <h2 className="text-xl font-semibold text-primary-900 mb-2">Can't find what you're looking for?</h2>
        <p className="text-primary-700 mb-4">
          If you can't find the page or calculator you need, please contact us and we'll be happy to help.
        </p>
        <Link 
          to="/contact-us" 
          className="btn bg-primary-600 text-white hover:bg-primary-700 inline-flex items-center"
        >
          <Phone className="h-4 w-4 mr-2" />
          Contact Us
        </Link>
      </div>
    </div>
  );
};

export default Sitemap;