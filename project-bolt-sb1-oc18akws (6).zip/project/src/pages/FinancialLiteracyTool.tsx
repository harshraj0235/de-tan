import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Search as SearchIcon, Filter, Tag, Calendar, User, Clock, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { blogPosts } from '../data/blogData';

export const FinancialLiteracyTool: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'quiz' | 'simulator' | 'blog'>('blog');
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  // Get unique categories from blog posts
  const categories = Array.from(
    new Set(blogPosts.flatMap(post => post.categories))
  ).sort();
  
  // Filter posts based on search and category
  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = searchTerm === '' || 
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
    const matchesCategory = selectedCategory === null || 
      post.categories.includes(selectedCategory);
      
    return matchesSearch && matchesCategory;
  });
  
  // Quiz questions
  const quizQuestions = [
    {
      question: "What percentage of your monthly income should ideally go towards saving and investing?",
      options: ["5-10%", "10-20%", "20-30%", "30-40%"],
      correctAnswer: "20-30%"
    },
    {
      question: "Which of these is generally considered the most tax-efficient investment option in India?",
      options: ["Fixed Deposit", "Public Provident Fund (PPF)", "Regular Mutual Funds", "Direct Stocks"],
      correctAnswer: "Public Provident Fund (PPF)"
    },
    {
      question: "What is the ideal debt-to-income ratio for good financial health?",
      options: ["Less than 20%", "20-30%", "30-40%", "40-50%"],
      correctAnswer: "Less than 20%"
    },
    {
      question: "How many months of expenses should an emergency fund ideally cover?",
      options: ["1-2 months", "3-6 months", "6-12 months", "Over 12 months"],
      correctAnswer: "3-6 months"
    },
    {
      question: "Which investment vehicle is typically best for long-term (15+ years) wealth creation?",
      options: ["Fixed Deposits", "Gold", "Equity Mutual Funds", "Real Estate"],
      correctAnswer: "Equity Mutual Funds"
    },
    {
      question: "What is the rule of 72 used for in financial planning?",
      options: [
        "To calculate monthly EMI",
        "To estimate how long it takes for money to double",
        "To determine tax liability",
        "To calculate retirement corpus"
      ],
      correctAnswer: "To estimate how long it takes for money to double"
    },
    {
      question: "Which of these is NOT a factor in determining your credit score?",
      options: [
        "Payment history",
        "Credit utilization",
        "Your salary",
        "Length of credit history"
      ],
      correctAnswer: "Your salary"
    },
    {
      question: "What is the ideal percentage of your income that should go towards housing (rent or EMI)?",
      options: ["Less than 15%", "15-25%", "25-35%", "35-45%"],
      correctAnswer: "25-35%"
    },
    {
      question: "Which of these insurance types should typically be prioritized first?",
      options: ["Life Insurance", "Health Insurance", "Home Insurance", "Vehicle Insurance"],
      correctAnswer: "Health Insurance"
    },
    {
      question: "What is the typical recommended allocation to equity investments for someone in their 30s?",
      options: ["30-40%", "50-60%", "70-80%", "90-100%"],
      correctAnswer: "70-80%"
    }
  ];
  
  // Calculate quiz score
  const calculateScore = () => {
    let score = 0;
    for (let i = 0; i < quizQuestions.length; i++) {
      if (answers[i] === quizQuestions[i].correctAnswer) {
        score++;
      }
    }
    return score;
  };
  
  // Handle quiz answer selection
  const handleAnswerSelect = (answer: string) => {
    setAnswers({
      ...answers,
      [currentQuestion]: answer
    });
  };
  
  // Handle next question
  const handleNextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setQuizCompleted(true);
    }
  };
  
  // Handle previous question
  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };
  
  // Reset quiz
  const resetQuiz = () => {
    setQuizStarted(false);
    setQuizCompleted(false);
    setCurrentQuestion(0);
    setAnswers({});
  };
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <button 
          onClick={() => navigate(-1)} 
          className="flex items-center text-neutral-600 hover:text-neutral-900 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          <span>Back</span>
        </button>
      </div>
      
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-4">Financial Literacy & Debt Management Tool</h1>
        <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
          Take control of your financial future with our interactive tools, personalized assessments, and expert resources
        </p>
      </div>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-12">
        <div className="flex border-b border-neutral-200">
          <button
            className={`flex-1 py-4 px-6 text-center font-medium ${
              activeTab === 'quiz'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            onClick={() => setActiveTab('quiz')}
          >
            Financial Health Quiz
          </button>
          <button
            className={`flex-1 py-4 px-6 text-center font-medium ${
              activeTab === 'simulator'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            onClick={() => setActiveTab('simulator')}
          >
            Debt Reduction Simulator
          </button>
          <button
            className={`flex-1 py-4 px-6 text-center font-medium ${
              activeTab === 'blog'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            onClick={() => setActiveTab('blog')}
          >
            Financial Education Blog
          </button>
        </div>
        
        <div className="p-6">
          {activeTab === 'quiz' && (
            <div>
              {!quizStarted ? (
                <div className="text-center py-8">
                  <h2 className="text-2xl font-bold text-neutral-900 mb-4">Financial Health Assessment</h2>
                  <p className="text-neutral-600 mb-8 max-w-2xl mx-auto">
                    Take our 10-question quiz to assess your financial literacy and receive personalized recommendations to improve your financial well-being.
                  </p>
                  <button
                    onClick={() => setQuizStarted(true)}
                    className="btn bg-primary-600 text-white hover:bg-primary-700"
                  >
                    Start Quiz
                  </button>
                </div>
              ) : !quizCompleted ? (
                <div>
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-neutral-600">Question {currentQuestion + 1} of {quizQuestions.length}</span>
                      <span className="text-sm font-medium text-neutral-600">{Math.round(((currentQuestion + 1) / quizQuestions.length) * 100)}% Complete</span>
                    </div>
                    <div className="w-full bg-neutral-200 rounded-full h-2.5">
                      <div 
                        className="bg-primary-600 h-2.5 rounded-full" 
                        style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-bold text-neutral-900 mb-6">{quizQuestions[currentQuestion].question}</h3>
                  
                  <div className="space-y-3 mb-8">
                    {quizQuestions[currentQuestion].options.map((option, index) => (
                      <button
                        key={index}
                        onClick={() => handleAnswerSelect(option)}
                        className={`w-full text-left p-4 rounded-lg border ${
                          answers[currentQuestion] === option
                            ? 'border-primary-600 bg-primary-50 text-primary-700'
                            : 'border-neutral-300 hover:border-neutral-400'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                  
                  <div className="flex justify-between">
                    <button
                      onClick={handlePreviousQuestion}
                      disabled={currentQuestion === 0}
                      className={`px-4 py-2 rounded-lg ${
                        currentQuestion === 0
                          ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                          : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      }`}
                    >
                      Previous
                    </button>
                    
                    <button
                      onClick={handleNextQuestion}
                      disabled={!answers[currentQuestion]}
                      className={`px-4 py-2 rounded-lg ${
                        !answers[currentQuestion]
                          ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                          : 'bg-primary-600 text-white hover:bg-primary-700'
                      }`}
                    >
                      {currentQuestion === quizQuestions.length - 1 ? 'Finish' : 'Next'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <h2 className="text-2xl font-bold text-neutral-900 mb-4">Your Financial Health Score</h2>
                  
                  <div className="w-48 h-48 mx-auto mb-6 relative">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle 
                        cx="50" 
                        cy="50" 
                        r="45" 
                        fill="none" 
                        stroke="#e5e7eb" 
                        strokeWidth="10" 
                      />
                      <circle 
                        cx="50" 
                        cy="50" 
                        r="45" 
                        fill="none" 
                        stroke={calculateScore() >= 8 ? "#22c55e" : calculateScore() >= 5 ? "#f59e0b" : "#ef4444"} 
                        strokeWidth="10" 
                        strokeDasharray="282.7"
                        strokeDashoffset={282.7 - (282.7 * calculateScore() / 10)}
                        strokeLinecap="round"
                        transform="rotate(-90 50 50)"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center flex-col">
                      <span className="text-4xl font-bold text-neutral-900">{calculateScore()}</span>
                      <span className="text-neutral-500">out of 10</span>
                    </div>
                  </div>
                  
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold text-neutral-900 mb-2">
                      {calculateScore() >= 8 
                        ? "Excellent Financial Literacy!" 
                        : calculateScore() >= 5 
                        ? "Good Financial Understanding" 
                        : "Room for Financial Growth"}
                    </h3>
                    <p className="text-neutral-600 max-w-2xl mx-auto">
                      {calculateScore() >= 8 
                        ? "You have a strong grasp of financial concepts and are likely making sound financial decisions. Keep up the good work and consider advanced strategies to optimize your finances further." 
                        : calculateScore() >= 5 
                        ? "You have a decent understanding of financial basics but could benefit from deepening your knowledge in certain areas. Review the recommendations below to strengthen your financial position." 
                        : "Your financial literacy could use some improvement. Don't worry - we've provided personalized recommendations below to help you build a stronger financial foundation."}
                    </p>
                  </div>
                  
                  <div className="bg-neutral-50 rounded-lg p-6 mb-8 text-left">
                    <h3 className="text-lg font-semibold text-neutral-900 mb-4">Personalized Recommendations</h3>
                    <ul className="space-y-3">
                      {calculateScore() < 7 && (
                        <li className="flex">
                          <span className="h-6 w-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center flex-shrink-0 mt-0.5 mr-3">1</span>
                          <div>
                            <h4 className="font-medium text-neutral-900">Build Your Emergency Fund</h4>
                            <p className="text-neutral-600 text-sm">Aim to save 3-6 months of expenses in a liquid account for unexpected situations.</p>
                          </div>
                        </li>
                      )}
                      {calculateScore() < 8 && (
                        <li className="flex">
                          <span className="h-6 w-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center flex-shrink-0 mt-0.5 mr-3">2</span>
                          <div>
                            <h4 className="font-medium text-neutral-900">Review Your Insurance Coverage</h4>
                            <p className="text-neutral-600 text-sm">Ensure you have adequate health and term life insurance before focusing on investments.</p>
                          </div>
                        </li>
                      )}
                      {calculateScore() < 6 && (
                        <li className="flex">
                          <span className="h-6 w-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center flex-shrink-0 mt-0.5 mr-3">3</span>
                          <div>
                            <h4 className="font-medium text-neutral-900">Create a Monthly Budget</h4>
                            <p className="text-neutral-600 text-sm">Track your income and expenses to understand your spending patterns and identify areas to save.</p>
                          </div>
                        </li>
                      )}
                      <li className="flex">
                        <span className="h-6 w-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center flex-shrink-0 mt-0.5 mr-3">{calculateScore() < 6 ? "4" : calculateScore() < 8 ? "3" : "1"}</span>
                        <div>
                          <h4 className="font-medium text-neutral-900">Start or Increase Your SIP Investments</h4>
                          <p className="text-neutral-600 text-sm">Consider investing {calculateScore() >= 8 ? "25-30%" : calculateScore() >= 5 ? "20-25%" : "15-20%"} of your income in equity mutual funds through SIPs for long-term goals.</p>
                        </div>
                      </li>
                      <li className="flex">
                        <span className="h-6 w-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center flex-shrink-0 mt-0.5 mr-3">{calculateScore() < 6 ? "5" : calculateScore() < 8 ? "4" : "2"}</span>
                        <div>
                          <h4 className="font-medium text-neutral-900">Optimize Your Tax Planning</h4>
                          <p className="text-neutral-600 text-sm">Review your tax-saving investments under Section 80C, 80D, and other applicable deductions.</p>
                        </div>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="flex justify-center space-x-4">
                    <button
                      onClick={resetQuiz}
                      className="btn bg-neutral-100 text-neutral-700 hover:bg-neutral-200"
                    >
                      Retake Quiz
                    </button>
                    <button
                      onClick={() => setActiveTab('simulator')}
                      className="btn bg-primary-600 text-white hover:bg-primary-700"
                    >
                      Try Debt Reduction Simulator
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'simulator' && (
            <div>
              <h2 className="text-2xl font-bold text-neutral-900 mb-6">Debt Reduction Simulator</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div>
                  <h3 className="text-lg font-semibold text-neutral-900 mb-4">Your Debts</h3>
                  
                  <div className="space-y-4 mb-6">
                    <div className="p-4 bg-white rounded-lg border border-neutral-200">
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium text-neutral-900">Home Loan</div>
                        <div className="text-sm text-neutral-500">8.5% interest</div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="text-2xl font-bold text-neutral-900">₹25,00,000</div>
                        <div className="text-sm text-neutral-500">EMI: ₹24,262</div>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-white rounded-lg border border-neutral-200">
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium text-neutral-900">Car Loan</div>
                        <div className="text-sm text-neutral-500">10.5% interest</div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="text-2xl font-bold text-neutral-900">₹5,00,000</div>
                        <div className="text-sm text-neutral-500">EMI: ₹10,746</div>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-white rounded-lg border border-neutral-200">
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium text-neutral-900">Personal Loan</div>
                        <div className="text-sm text-neutral-500">14% interest</div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="text-2xl font-bold text-neutral-900">₹2,00,000</div>
                        <div className="text-sm text-neutral-500">EMI: ₹9,331</div>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-white rounded-lg border border-neutral-200">
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium text-neutral-900">Credit Card Debt</div>
                        <div className="text-sm text-neutral-500">36% interest</div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="text-2xl font-bold text-neutral-900">₹1,50,000</div>
                        <div className="text-sm text-neutral-500">Min Payment: ₹7,500</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <div className="flex justify-between items-center mb-4">
                      <div className="font-medium text-neutral-900">Total Debt</div>
                      <div className="text-xl font-bold text-neutral-900">₹33,50,000</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="font-medium text-neutral-900">Monthly Payments</div>
                      <div className="text-xl font-bold text-neutral-900">₹51,839</div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-neutral-900 mb-4">Debt Reduction Strategy</h3>
                  
                  <div className="p-4 bg-white rounded-lg border border-neutral-200 mb-6">
                    <h4 className="font-medium text-neutral-900 mb-3">Extra Monthly Payment</h4>
                    <div className="flex items-center space-x-4">
                      <input
                        type="range"
                        min="0"
                        max="20000"
                        step="1000"
                        defaultValue="5000"
                        className="slider flex-grow"
                      />
                      <span className="text-neutral-900 font-medium whitespace-nowrap">₹5,000</span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-white rounded-lg border border-neutral-200 mb-6">
                    <h4 className="font-medium text-neutral-900 mb-3">Debt Payoff Method</h4>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="avalanche"
                          name="payoff-method"
                          defaultChecked
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-neutral-300"
                        />
                        <label htmlFor="avalanche" className="ml-2 block text-sm text-neutral-900">
                          <span className="font-medium">Avalanche Method</span> - Pay highest interest first (saves the most money)
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="snowball"
                          name="payoff-method"
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-neutral-300"
                        />
                        <label htmlFor="snowball" className="ml-2 block text-sm text-neutral-900">
                          <span className="font-medium">Snowball Method</span> - Pay smallest balance first (builds momentum)
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-primary-50 rounded-lg border border-primary-100 mb-6">
                    <h4 className="font-medium text-primary-900 mb-3">Results with Extra Payment</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-neutral-700">Debt-free in</span>
                        <span className="font-medium text-neutral-900">5 years 3 months</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-700">Time saved</span>
                        <span className="font-medium text-success-600">9 years 9 months</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-700">Interest saved</span>
                        <span className="font-medium text-success-600">₹14,32,500</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-white rounded-lg border border-neutral-200">
                    <h4 className="font-medium text-neutral-900 mb-3">Recommended Payoff Order</h4>
                    <ol className="space-y-2 text-sm">
                      <li className="flex justify-between items-center p-2 bg-error-50 rounded">
                        <span className="font-medium">1. Credit Card Debt</span>
                        <span>36% interest</span>
                      </li>
                      <li className="flex justify-between items-center p-2 bg-neutral-50 rounded">
                        <span className="font-medium">2. Personal Loan</span>
                        <span>14% interest</span>
                      </li>
                      <li className="flex justify-between items-center p-2 bg-neutral-50 rounded">
                        <span className="font-medium">3. Car Loan</span>
                        <span>10.5% interest</span>
                      </li>
                      <li className="flex justify-between items-center p-2 bg-neutral-50 rounded">
                        <span className="font-medium">4. Home Loan</span>
                        <span>8.5% interest</span>
                      </li>
                    </ol>
                  </div>
                </div>
              </div>
              
              <div className="bg-neutral-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-neutral-900 mb-4">Debt Management Tips</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-white rounded-lg">
                    <h4 className="font-medium text-neutral-900 mb-2">Prioritize High-Interest Debt</h4>
                    <p className="text-sm text-neutral-600">Focus on paying off high-interest debts like credit cards first to minimize interest costs and accelerate your debt-free journey.</p>
                  </div>
                  <div className="p-4 bg-white rounded-lg">
                    <h4 className="font-medium text-neutral-900 mb-2">Consider Balance Transfers</h4>
                    <p className="text-sm text-neutral-600">Transfer high-interest credit card balances to cards with lower interest rates or 0% introductory offers to reduce interest payments.</p>
                  </div>
                  <div className="p-4 bg-white rounded-lg">
                    <h4 className="font-medium text-neutral-900 mb-2">Explore Loan Consolidation</h4>
                    <p className="text-sm text-neutral-600">Consolidate multiple high-interest loans into a single lower-interest loan to simplify payments and potentially reduce interest costs.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'blog' && (
            <div>
              <div className="flex flex-col md:flex-row gap-6 mb-8">
                <div className="w-full md:w-1/4">
                  <div className="mb-6">
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <SearchIcon className="h-5 w-5 text-neutral-400" />
                      </div>
                      <input
                        type="text"
                        placeholder="Search articles..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="input pl-10"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-semibold text-neutral-900">Categories</h3>
                      {selectedCategory && (
                        <button
                          onClick={() => setSelectedCategory(null)}
                          className="text-sm text-primary-600 hover:text-primary-700"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                    <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                      <button
                        onClick={() => setSelectedCategory(null)}
                        className={`block w-full text-left px-3 py-2 rounded-lg text-sm ${
                          selectedCategory === null 
                            ? 'bg-primary-100 text-primary-800 font-medium' 
                            : 'text-neutral-700 hover:bg-neutral-100'
                        }`}
                      >
                        All Categories
                      </button>
                      {categories.map(category => (
                        <button
                          key={category}
                          onClick={() => setSelectedCategory(category)}
                          className={`block w-full text-left px-3 py-2 rounded-lg text-sm ${
                            selectedCategory === category 
                              ? 'bg-primary-100 text-primary-800 font-medium' 
                              : 'text-neutral-700 hover:bg-neutral-100'
                          }`}
                        >
                          {category}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="w-full md:w-3/4">
                  {filteredPosts.length === 0 ? (
                    <div className="text-center py-12 bg-neutral-50 rounded-lg">
                      <p className="text-lg text-neutral-600">No articles found matching your criteria.</p>
                      <button 
                        onClick={() => {
                          setSearchTerm('');
                          setSelectedCategory(null);
                        }}
                        className="mt-4 text-primary-600 hover:text-primary-700 font-medium"
                      >
                        Clear filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredPosts.map(post => (
                        <div 
                          key={post.id} 
                          className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-neutral-200"
                        >
                          <div className="h-48 overflow-hidden">
                            <img 
                              src={post.coverImage} 
                              alt={post.title} 
                              className="w-full h-full object-cover transition-transform hover:scale-105"
                            />
                          </div>
                          <div className="p-5">
                            <div className="flex flex-wrap gap-2 mb-3">
                              {post.categories.slice(0, 2).map(category => (
                                <span 
                                  key={category} 
                                  className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800"
                                >
                                  {category}
                                </span>
                              ))}
                            </div>
                            <h3 className="text-lg font-semibold text-neutral-900 mb-2 line-clamp-2">{post.title}</h3>
                            <p className="text-neutral-600 text-sm mb-3 line-clamp-3">{post.excerpt}</p>
                            <div className="flex items-center text-xs text-neutral-500 mb-3">
                              <User className="h-3 w-3 mr-1" />
                              <span>{post.author}</span>
                              <span className="mx-2">•</span>
                              <Calendar className="h-3 w-3 mr-1" />
                              <span>{post.date}</span>
                              <span className="mx-2">•</span>
                              <Clock className="h-3 w-3 mr-1" />
                              <span>{post.readTime}</span>
                            </div>
                            <Link 
                              to={`/blog/${post.slug}`}
                              className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center"
                            >
                              Read Article
                              <ChevronRight className="h-4 w-4 ml-1" />
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {filteredPosts.length > 0 && (
                    <div className="mt-8 flex justify-center">
                      <nav className="inline-flex rounded-md shadow">
                        <a href="#" className="px-4 py-2 rounded-l-md border border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                          Previous
                        </a>
                        <a href="#" className="px-4 py-2 border-t border-b border-neutral-300 bg-white text-sm font-medium text-primary-600 hover:bg-primary-50">
                          1
                        </a>
                        <a href="#" className="px-4 py-2 border-t border-b border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                          2
                        </a>
                        <a href="#" className="px-4 py-2 border-t border-b border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                          3
                        </a>
                        <a href="#" className="px-4 py-2 rounded-r-md border border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                          Next
                        </a>
                      </nav>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white rounded-xl shadow-md p-6 border border-neutral-200">
          <h3 className="text-xl font-semibold text-neutral-900 mb-4">Financial Health Checkup</h3>
          <p className="text-neutral-600 mb-4">
            Take our comprehensive quiz to assess your financial literacy and receive personalized recommendations.
          </p>
          <button
            onClick={() => {
              setActiveTab('quiz');
              setQuizStarted(false);
              setQuizCompleted(false);
            }}
            className="btn bg-primary-600 text-white hover:bg-primary-700 w-full"
          >
            Start Assessment
          </button>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 border border-neutral-200">
          <h3 className="text-xl font-semibold text-neutral-900 mb-4">Debt Reduction Planner</h3>
          <p className="text-neutral-600 mb-4">
            Use our interactive simulator to create a personalized plan to become debt-free faster.
          </p>
          <button
            onClick={() => setActiveTab('simulator')}
            className="btn bg-primary-600 text-white hover:bg-primary-700 w-full"
          >
            Create Plan
          </button>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 border border-neutral-200">
          <h3 className="text-xl font-semibold text-neutral-900 mb-4">Expert Financial Articles</h3>
          <p className="text-neutral-600 mb-4">
            Explore our collection of in-depth articles on personal finance, investing, and financial planning.
          </p>
          <button
            onClick={() => setActiveTab('blog')}
            className="btn bg-primary-600 text-white hover:bg-primary-700 w-full"
          >
            Browse Articles
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-8 border border-neutral-200">
        <h2 className="text-2xl font-bold text-neutral-900 mb-6 text-center">Financial Calculators</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-4">
          <Link to="/calculators/budget-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Budget Calculator</h3>
            <p className="text-sm text-neutral-600">Plan your monthly budget</p>
          </Link>
          
          <Link to="/calculators/emergency-fund-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Emergency Fund</h3>
            <p className="text-sm text-neutral-600">Calculate your safety net</p>
          </Link>
          
          <Link to="/calculators/debt-equity-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Debt-to-Income</h3>
            <p className="text-sm text-neutral-600">Assess your debt health</p>
          </Link>
          
          <Link to="/calculators/loan-affordability-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Loan Affordability</h3>
            <p className="text-sm text-neutral-600">How much can you borrow?</p>
          </Link>
          
          <Link to="/calculators/loan-prepayment-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Loan Prepayment</h3>
            <p className="text-sm text-neutral-600">Calculate interest savings</p>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Link to="/calculators/credit-card-emi-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Credit Card EMI</h3>
            <p className="text-sm text-neutral-600">Plan your EMI conversion</p>
          </Link>
          
          <Link to="/calculators/emi-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">EMI Calculator</h3>
            <p className="text-sm text-neutral-600">Calculate loan payments</p>
          </Link>
          
          <Link to="/calculators/sip-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">SIP Calculator</h3>
            <p className="text-sm text-neutral-600">Plan your investments</p>
          </Link>
          
          <Link to="/calculators/retirement-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Retirement Planner</h3>
            <p className="text-sm text-neutral-600">Plan for your future</p>
          </Link>
          
          <Link to="/calculators/human-life-value-calculator" className="p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors text-center">
            <h3 className="font-medium text-neutral-900 mb-1">Insurance Needs</h3>
            <p className="text-sm text-neutral-600">Calculate coverage needs</p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default FinancialLiteracyTool;