import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Github, Code, Download, ExternalLink, Search, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface TemplateItem {
  id: string;
  name: string;
  description: string;
  category: string;
  tags: string[];
  demoUrl: string;
  downloadUrl: string;
  imageUrl: string;
  stars: number;
  author: string;
  license: string;
}

export const OpenSourceTemplates: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState<string | null>(null);
  
  const categories = [
    "Crypto Dashboard",
    "Financial Calculator",
    "Trading Platform",
    "Portfolio Tracker",
    "Admin Dashboard",
    "Landing Page"
  ];
  
  const templates: TemplateItem[] = [
    {
      id: "crypto-dashboard-1",
      name: "CryptoDash",
      description: "A modern cryptocurrency dashboard with real-time price tracking, portfolio management, and interactive charts.",
      category: "Crypto Dashboard",
      tags: ["React", "Chart.js", "Responsive", "Dark Mode"],
      demoUrl: "https://demo.themeselection.com/sneat-bootstrap-html-admin-template/html/vertical-menu-template/index.html",
      downloadUrl: "https://github.com/puikinsh/crypto-admin-dashboard-template",
      imageUrl: "https://images.pexels.com/photos/7567486/pexels-photo-7567486.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 1250,
      author: "ThemeSelection",
      license: "MIT"
    },
    {
      id: "finance-calc-1",
      name: "FinCalc Suite",
      description: "A comprehensive collection of financial calculators including loan, investment, tax, and retirement planning tools.",
      category: "Financial Calculator",
      tags: ["JavaScript", "Bootstrap", "Responsive", "Customizable"],
      demoUrl: "https://colorlib.com/wp/template/bootstrap-financial-calculator/",
      downloadUrl: "https://github.com/topics/financial-calculator",
      imageUrl: "https://images.pexels.com/photos/6693661/pexels-photo-6693661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 875,
      author: "Colorlib",
      license: "MIT"
    },
    {
      id: "trading-platform-1",
      name: "TradingView Clone",
      description: "An open-source trading platform with advanced charting capabilities, technical indicators, and trading tools.",
      category: "Trading Platform",
      tags: ["JavaScript", "D3.js", "WebSockets", "Responsive"],
      demoUrl: "https://github.com/tradingview/charting_library/",
      downloadUrl: "https://github.com/tradingview/charting_library/",
      imageUrl: "https://images.pexels.com/photos/6770610/pexels-photo-6770610.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 2100,
      author: "TradingView",
      license: "Custom"
    },
    {
      id: "portfolio-tracker-1",
      name: "CryptoFolio",
      description: "A cryptocurrency portfolio tracker with performance analytics, historical data, and tax reporting features.",
      category: "Portfolio Tracker",
      tags: ["Vue.js", "Firebase", "Responsive", "PWA"],
      demoUrl: "https://demo.dashboardpack.com/cryptocurrency-html/",
      downloadUrl: "https://github.com/topics/crypto-portfolio",
      imageUrl: "https://images.pexels.com/photos/6780789/pexels-photo-6780789.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 950,
      author: "DashboardPack",
      license: "MIT"
    },
    {
      id: "admin-dashboard-1",
      name: "Crypto Admin",
      description: "A feature-rich admin dashboard template for cryptocurrency and financial applications with multiple layouts and components.",
      category: "Admin Dashboard",
      tags: ["HTML", "CSS", "JavaScript", "Responsive"],
      demoUrl: "https://preview.themeforest.net/item/crypto-admin-responsive-bootstrap-admin-dashboard-template/full_screen_preview/21272285",
      downloadUrl: "https://github.com/puikinsh/crypto-admin-dashboard-template",
      imageUrl: "https://images.pexels.com/photos/7567555/pexels-photo-7567555.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 1450,
      author: "Colorlib",
      license: "MIT"
    },
    {
      id: "landing-page-1",
      name: "CryptoLaunch",
      description: "A modern landing page template for cryptocurrency projects, ICOs, and financial services with animated sections and conversion-focused design.",
      category: "Landing Page",
      tags: ["HTML", "CSS", "JavaScript", "Animation"],
      demoUrl: "https://html5up.net/paradigm-shift",
      downloadUrl: "https://html5up.net/paradigm-shift/download",
      imageUrl: "https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 780,
      author: "HTML5 UP",
      license: "Creative Commons"
    },
    {
      id: "crypto-dashboard-2",
      name: "DashCrypto",
      description: "A lightweight cryptocurrency dashboard with market overview, wallet integration, and transaction history.",
      category: "Crypto Dashboard",
      tags: ["React", "Redux", "Tailwind CSS", "API Integration"],
      demoUrl: "https://preview.keenthemes.com/metronic/demo1/index.html",
      downloadUrl: "https://github.com/topics/crypto-dashboard",
      imageUrl: "https://images.pexels.com/photos/6781341/pexels-photo-6781341.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 920,
      author: "KeenThemes",
      license: "MIT"
    },
    {
      id: "finance-calc-2",
      name: "InvestCalc Pro",
      description: "Advanced investment calculators with compound interest, SIP returns, goal planning, and tax optimization tools.",
      category: "Financial Calculator",
      tags: ["JavaScript", "Chart.js", "Responsive", "Print-friendly"],
      demoUrl: "https://bootstrapmade.com/demo/templates/Arsha/",
      downloadUrl: "https://github.com/topics/investment-calculator",
      imageUrl: "https://images.pexels.com/photos/7567535/pexels-photo-7567535.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 650,
      author: "BootstrapMade",
      license: "MIT"
    },
    {
      id: "trading-platform-2",
      name: "ForexTrader",
      description: "A forex trading platform template with real-time charts, economic calendar, and trading signals integration.",
      category: "Trading Platform",
      tags: ["JavaScript", "WebSockets", "Responsive", "Dark Mode"],
      demoUrl: "https://preview.themeforest.net/item/tradient-cryptocurrency-trading-dashboard-html-template/full_screen_preview/22501621",
      downloadUrl: "https://github.com/topics/trading-platform",
      imageUrl: "https://images.pexels.com/photos/6771900/pexels-photo-6771900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 1100,
      author: "ThemeForest",
      license: "MIT"
    },
    {
      id: "portfolio-tracker-2",
      name: "StockFolio",
      description: "A stock portfolio tracker with dividend tracking, performance analytics, and market news integration.",
      category: "Portfolio Tracker",
      tags: ["React", "D3.js", "Responsive", "API Integration"],
      demoUrl: "https://www.creative-tim.com/product/black-dashboard",
      downloadUrl: "https://github.com/topics/stock-portfolio",
      imageUrl: "https://images.pexels.com/photos/6802042/pexels-photo-6802042.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 830,
      author: "Creative Tim",
      license: "MIT"
    },
    {
      id: "admin-dashboard-2",
      name: "FinDash",
      description: "A financial admin dashboard with analytics, reporting, user management, and customizable widgets.",
      category: "Admin Dashboard",
      tags: ["Bootstrap", "jQuery", "Responsive", "Dark Mode"],
      demoUrl: "https://adminlte.io/themes/v3/index.html",
      downloadUrl: "https://github.com/ColorlibHQ/AdminLTE",
      imageUrl: "https://images.pexels.com/photos/7567441/pexels-photo-7567441.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 1850,
      author: "Colorlib",
      license: "MIT"
    },
    {
      id: "landing-page-2",
      name: "FinTech Pro",
      description: "A professional landing page template for fintech startups, financial apps, and banking services.",
      category: "Landing Page",
      tags: ["HTML", "CSS", "JavaScript", "Responsive"],
      demoUrl: "https://html5up.net/stellar",
      downloadUrl: "https://html5up.net/stellar/download",
      imageUrl: "https://images.pexels.com/photos/7821486/pexels-photo-7821486.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 720,
      author: "HTML5 UP",
      license: "Creative Commons"
    },
    {
      id: "sb-admin-2",
      name: "SB Admin 2",
      description: "A free Bootstrap admin dashboard template with responsive design and modern components for financial applications.",
      category: "Admin Dashboard",
      tags: ["Bootstrap", "jQuery", "Chart.js", "Responsive"],
      demoUrl: "https://startbootstrap.com/previews/sb-admin-2",
      downloadUrl: "https://github.com/StartBootstrap/startbootstrap-sb-admin-2",
      imageUrl: "https://images.pexels.com/photos/7567617/pexels-photo-7567617.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 9800,
      author: "Start Bootstrap",
      license: "MIT"
    },
    {
      id: "adminlte",
      name: "AdminLTE",
      description: "A highly popular admin dashboard template perfect for financial applications and data visualization.",
      category: "Admin Dashboard",
      tags: ["Bootstrap", "jQuery", "Responsive", "Widgets"],
      demoUrl: "https://adminlte.io/themes/v3/",
      downloadUrl: "https://github.com/ColorlibHQ/AdminLTE",
      imageUrl: "https://images.pexels.com/photos/7567538/pexels-photo-7567538.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      stars: 41500,
      author: "Colorlib",
      license: "MIT"
    }
  ];
  
  // Filter templates based on search and category
  const filteredTemplates = templates.filter(template => {
    const matchesSearch = searchTerm === '' || 
      template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      template.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      template.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
    const matchesCategory = selectedCategory === null || 
      template.category === selectedCategory;
      
    return matchesSearch && matchesCategory;
  });
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <button 
          onClick={() => navigate(-1)} 
          className="flex items-center text-neutral-600 hover:text-neutral-900 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          <span>Back</span>
        </button>
      </div>
      
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-4">Open Source Templates</h1>
        <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
          Discover free, customizable HTML/CSS/JS templates for crypto, forex, and financial tools to jumpstart your project
        </p>
      </div>
      
      <div className="flex flex-col md:flex-row gap-6 mb-8">
        <div className="w-full md:w-1/4">
          <div className="mb-6">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-neutral-400" />
              </div>
              <input
                type="text"
                placeholder="Search templates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input pl-10"
              />
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-semibold text-neutral-900">Categories</h3>
              {selectedCategory && (
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="text-sm text-primary-600 hover:text-primary-700"
                >
                  Clear
                </button>
              )}
            </div>
            <div className="space-y-2">
              <button
                onClick={() => setSelectedCategory(null)}
                className={`block w-full text-left px-3 py-2 rounded-lg text-sm ${
                  selectedCategory === null 
                    ? 'bg-primary-100 text-primary-800 font-medium' 
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
              >
                All Categories
              </button>
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`block w-full text-left px-3 py-2 rounded-lg text-sm ${
                    selectedCategory === category 
                      ? 'bg-primary-100 text-primary-800 font-medium' 
                      : 'text-neutral-700 hover:bg-neutral-100'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-primary-50 rounded-lg border border-primary-100">
            <h3 className="text-lg font-semibold text-primary-900 mb-2">Need Help?</h3>
            <p className="text-sm text-primary-700 mb-3">
              Not sure which template to choose? Contact us for personalized recommendations based on your project requirements.
            </p>
            <Link 
              to="/contact-us" 
              className="text-sm font-medium text-primary-700 hover:text-primary-800 flex items-center"
            >
              Get in touch
              <ExternalLink className="h-4 w-4 ml-1" />
            </Link>
          </div>
        </div>
        
        <div className="w-full md:w-3/4">
          {filteredTemplates.length === 0 ? (
            <div className="text-center py-12 bg-neutral-50 rounded-lg">
              <p className="text-lg text-neutral-600">No templates found matching your criteria.</p>
              <button 
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory(null);
                }}
                className="mt-4 text-primary-600 hover:text-primary-700 font-medium"
              >
                Clear filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredTemplates.map(template => (
                <div 
                  key={template.id} 
                  className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow border border-neutral-200"
                >
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={template.imageUrl} 
                      alt={template.name} 
                      className="w-full h-full object-cover transition-transform hover:scale-105"
                    />
                  </div>
                  <div className="p-5">
                    <div className="flex justify-between items-center mb-3">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                        {template.category}
                      </span>
                      <div className="flex items-center text-neutral-500">
                        <Github className="h-4 w-4 mr-1" />
                        <span className="text-xs">{template.stars} stars</span>
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-neutral-900 mb-2">{template.name}</h3>
                    <p className="text-neutral-600 text-sm mb-3 line-clamp-2">{template.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {template.tags.map(tag => (
                        <span 
                          key={tag} 
                          className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-neutral-100 text-neutral-800"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <a 
                        href={template.demoUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center"
                      >
                        Live Demo
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </a>
                      <a 
                        href={template.downloadUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center"
                      >
                        Download
                        <Download className="h-3 w-3 ml-1" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-8 border border-neutral-200 mb-12">
        <h2 className="text-2xl font-bold text-neutral-900 mb-6 text-center">Top Platforms for Open-Source Templates</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="p-6 bg-neutral-50 rounded-lg">
            <h3 className="text-lg font-semibold text-neutral-900 mb-3">GitHub</h3>
            <ul className="space-y-2 text-neutral-600 text-sm">
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://github.com/topics/crypto-dashboard" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  Crypto Dashboard Templates
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://github.com/curated-intel/awesome-dashboards" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  Awesome Dashboards Collection
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://github.com/tradingview/charting_library/" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  TradingView Charting Library
                </a>
              </li>
            </ul>
          </div>
          
          <div className="p-6 bg-neutral-50 rounded-lg">
            <h3 className="text-lg font-semibold text-neutral-900 mb-3">Template Websites</h3>
            <ul className="space-y-2 text-neutral-600 text-sm">
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://colorlib.com/wp/free-bootstrap-admin-dashboard-templates/" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  Colorlib Admin Dashboards
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://bootstrapmade.com/bootstrap-templates/" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  BootstrapMade Templates
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://www.creative-tim.com/bootstrap-themes/free" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  Creative Tim Free Templates
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://html5up.net/" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  HTML5 UP Templates
                </a>
              </li>
            </ul>
          </div>
          
          <div className="p-6 bg-neutral-50 rounded-lg">
            <h3 className="text-lg font-semibold text-neutral-900 mb-3">Popular Examples</h3>
            <ul className="space-y-2 text-neutral-600 text-sm">
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://github.com/StartBootstrap/startbootstrap-sb-admin-2" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  SB Admin 2 (9.8k+ stars)
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://github.com/ColorlibHQ/AdminLTE" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  AdminLTE (41.5k+ stars)
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://coreui.io/" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  CoreUI Free Bootstrap Admin
                </a>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <a href="https://github.com/justdjango/crypto-dashboard" target="_blank" rel="noopener noreferrer" className="hover:text-primary-600">
                  Vue Crypto Dashboard
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="p-6 bg-primary-50 rounded-lg">
          <h3 className="text-lg font-semibold text-primary-900 mb-3">Tips for Success</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-primary-800 text-sm">
            <div className="flex items-start">
              <span className="text-primary-600 mr-2">•</span>
              <p>Always check the license (MIT, Apache, etc.) — most are free for personal and commercial use, but some require attribution.</p>
            </div>
            <div className="flex items-start">
              <span className="text-primary-600 mr-2">•</span>
              <p>For crypto/finance, look for templates with built-in charting and data tables.</p>
            </div>
            <div className="flex items-start">
              <span className="text-primary-600 mr-2">•</span>
              <p>Use chart libraries like Chart.js or ApexCharts for dynamic data visualization.</p>
            </div>
            <div className="flex items-start">
              <span className="text-primary-600 mr-2">•</span>
              <p>Consider mobile responsiveness and cross-browser compatibility for wider reach.</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-8 border border-neutral-200 mb-12">
        <h2 className="text-2xl font-bold text-neutral-900 mb-6 text-center">How to Use These Templates</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-neutral-50 rounded-lg">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
              <Download className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-900 mb-2">1. Download the Template</h3>
            <p className="text-neutral-600 text-sm">
              Choose a template that fits your project needs and download the source files from GitHub or the provided link.
            </p>
          </div>
          
          <div className="p-6 bg-neutral-50 rounded-lg">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
              <Code className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-900 mb-2">2. Customize the Code</h3>
            <p className="text-neutral-600 text-sm">
              Modify the HTML, CSS, and JavaScript files to match your branding, add your features, and connect to your data sources.
            </p>
          </div>
          
          <div className="p-6 bg-neutral-50 rounded-lg">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
              <ExternalLink className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-900 mb-2">3. Deploy Your Project</h3>
            <p className="text-neutral-600 text-sm">
              Host your customized template on platforms like GitHub Pages, Vercel, or Netlify to make it accessible online.
            </p>
          </div>
        </div>
      </div>
      
      <div className="bg-primary-50 rounded-xl p-8 border border-primary-100">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-primary-900 mb-2">Need a Custom Solution?</h2>
          <p className="text-primary-700 max-w-2xl mx-auto">
            If you can't find a template that meets your specific requirements, we can help you build a custom solution tailored to your needs.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link 
            to="/contact-us" 
            className="btn bg-primary-600 text-white hover:bg-primary-700"
          >
            Contact Us
          </Link>
          <a 
            href="https://github.com/topics/financial-dashboard" 
            target="_blank" 
            rel="noopener noreferrer"
            className="btn bg-white text-neutral-800 border border-neutral-300 hover:bg-neutral-50 flex items-center"
          >
            <Github className="h-4 w-4 mr-2" />
            Explore More on GitHub
          </a>
        </div>
      </div>
    </div>
  );
};

export default OpenSourceTemplates;