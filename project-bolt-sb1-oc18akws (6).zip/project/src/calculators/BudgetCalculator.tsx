import React, { useState } from 'react';

export const BudgetCalculator: React.FC = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Budget Calculator</h2>
      {/* Calculator implementation will go here */}
      <p>Calculator coming soon</p>
    </div>
  );
};

export default BudgetCalculator;