import React, { useState, useEffect } from 'react';
import { formatCurrency } from '../utils/calculatorUtils';
import { Sliders, Calculator, PieChart } from 'lucide-react';
import { ResultChart } from '../components/ResultChart';

export const CompoundInterestCalculator: React.FC = () => {
  const [principal, setPrincipal] = useState<number>(100000);
  const [interestRate, setInterestRate] = useState<number>(10);
  const [timePeriod, setTimePeriod] = useState<number>(5);
  const [compoundingFrequency, setCompoundingFrequency] = useState<'annually' | 'semi-annually' | 'quarterly' | 'monthly' | 'daily'>('annually');
  const [additionalContribution, setAdditionalContribution] = useState<number>(0);
  const [contributionFrequency, setContributionFrequency] = useState<'monthly' | 'quarterly' | 'annually'>('monthly');
  
  const [maturityAmount, setMaturityAmount] = useState<number>(0);
  const [totalInvestment, setTotalInvestment] = useState<number>(0);
  const [totalInterest, setTotalInterest] = useState<number>(0);
  const [yearlyBreakup, setYearlyBreakup] = useState<Array<{year: number; investment: number; interest: number; balance: number}>>([]);
  
  useEffect(() => {
    // Calculate compound interest
    let compoundingPerYear = 1;
    switch (compoundingFrequency) {
      case 'annually':
        compoundingPerYear = 1;
        break;
      case 'semi-annually':
        compoundingPerYear = 2;
        break;
      case 'quarterly':
        compoundingPerYear = 4;
        break;
      case 'monthly':
        compoundingPerYear = 12;
        break;
      case 'daily':
        compoundingPerYear = 365;
        break;
    }
    
    // Calculate contribution frequency
    let contributionsPerYear = 12;
    switch (contributionFrequency) {
      case 'monthly':
        contributionsPerYear = 12;
        break;
      case 'quarterly':
        contributionsPerYear = 4;
        break;
      case 'annually':
        contributionsPerYear = 1;
        break;
    }
    
    const ratePerPeriod = interestRate / 100 / compoundingPerYear;
    const periodsTotal = compoundingPerYear * timePeriod;
    
    // Calculate with additional contributions
    let balance = principal;
    let totalContributions = principal;
    const breakup: Array<{year: number; investment: number; interest: number; balance: number}> = [];
    
    // For each year, track the investment and interest
    for (let year = 1; year <= timePeriod; year++) {
      let yearStartBalance = balance;
      let yearContributions = 0;
      
      // Calculate for each compounding period in the year
      for (let period = 1; period <= compoundingPerYear; period++) {
        // Add contributions for this period
        const contributionsThisPeriod = Math.floor(contributionsPerYear / compoundingPerYear);
        for (let i = 0; i < contributionsThisPeriod; i++) {
          balance += additionalContribution;
          yearContributions += additionalContribution;
          totalContributions += additionalContribution;
        }
        
        // Apply interest for this period
        balance *= (1 + ratePerPeriod);
      }
      
      // Handle any remaining contributions due to rounding
      const remainingContributions = contributionsPerYear % compoundingPerYear;
      for (let i = 0; i < remainingContributions; i++) {
        balance += additionalContribution;
        yearContributions += additionalContribution;
        totalContributions += additionalContribution;
      }
      
      // Calculate interest earned this year
      const yearEndBalance = balance;
      const yearInterest = yearEndBalance - yearStartBalance - yearContributions;
      
      breakup.push({
        year,
        investment: yearContributions,
        interest: yearInterest,
        balance: yearEndBalance
      });
    }
    
    setMaturityAmount(balance);
    setTotalInvestment(totalContributions);
    setTotalInterest(balance - totalContributions);
    setYearlyBreakup(breakup);
    
  }, [principal, interestRate, timePeriod, compoundingFrequency, additionalContribution, contributionFrequency]);
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-6">
        <h2 className="text-xl font-semibold text-neutral-900 flex items-center">
          <Sliders className="w-5 h-5 mr-2 text-[--primary-600]" />
          Investment Details
        </h2>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <label htmlFor="principal" className="text-sm font-medium text-neutral-700">
                Principal Amount (₹)
              </label>
              <span className="text-sm text-neutral-500">
                {formatCurrency(principal)}
              </span>
            </div>
            <input 
              type="range" 
              id="principal"
              min="1000" 
              max="10000000" 
              step="1000" 
              value={principal} 
              onChange={(e) => setPrincipal(Number(e.target.value))}
              className="slider"
            />
            <div className="flex justify-between mt-1 text-xs text-neutral-500">
              <span>₹1,000</span>
              <span>₹1 Crore</span>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between mb-2">
              <label htmlFor="interest-rate" className="text-sm font-medium text-neutral-700">
                Interest Rate (% p.a.)
              </label>
              <span className="text-sm text-neutral-500">
                {interestRate}%
              </span>
            </div>
            <input 
              type="range" 
              id="interest-rate"
              min="1" 
              max="30" 
              step="0.1" 
              value={interestRate} 
              onChange={(e) => setInterestRate(Number(e.target.value))}
              className="slider"
            />
            <div className="flex justify-between mt-1 text-xs text-neutral-500">
              <span>1%</span>
              <span>30%</span>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between mb-2">
              <label htmlFor="time-period" className="text-sm font-medium text-neutral-700">
                Time Period (Years)
              </label>
              <span className="text-sm text-neutral-500">
                {timePeriod} years
              </span>
            </div>
            <input 
              type="range" 
              id="time-period"
              min="1" 
              max="30" 
              step="1" 
              value={timePeriod} 
              onChange={(e) => setTimePeriod(Number(e.target.value))}
              className="slider"
            />
            <div className="flex justify-between mt-1 text-xs text-neutral-500">
              <span>1 Year</span>
              <span>30 Years</span>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium text-neutral-700 mb-2 block">
              Compounding Frequency
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <button
                className={`px-3 py-2 rounded-lg text-sm font-medium ${
                  compoundingFrequency === 'annually'
                    ? 'bg-[--primary-100] text-[--primary-800]'
                    : 'bg-neutral-100 text-neutral-600'
                }`}
                onClick={() => setCompoundingFrequency('annually')}
              >
                Annually
              </button>
              <button
                className={`px-3 py-2 rounded-lg text-sm font-medium ${
                  compoundingFrequency === 'semi-annually'
                    ? 'bg-[--primary-100] text-[--primary-800]'
                    : 'bg-neutral-100 text-neutral-600'
                }`}
                onClick={() => setCompoundingFrequency('semi-annually')}
              >
                Semi-Annually
              </button>
              <button
                className={`px-3 py-2 rounded-lg text-sm font-medium ${
                  compoundingFrequency === 'quarterly'
                    ? 'bg-[--primary-100] text-[--primary-800]'
                    : 'bg-neutral-100 text-neutral-600'
                }`}
                onClick={() => setCompoundingFrequency('quarterly')}
              >
                Quarterly
              </button>
              <button
                className={`px-3 py-2 rounded-lg text-sm font-medium ${
                  compoundingFrequency === 'monthly'
                    ? 'bg-[--primary-100] text-[--primary-800]'
                    : 'bg-neutral-100 text-neutral-600'
                }`}
                onClick={() => setCompoundingFrequency('monthly')}
              >
                Monthly
              </button>
              <button
                className={`px-3 py-2 rounded-lg text-sm font-medium ${
                  compoundingFrequency === 'daily'
                    ? 'bg-[--primary-100] text-[--primary-800]'
                    : 'bg-neutral-100 text-neutral-600'
                }`}
                onClick={() => setCompoundingFrequency('daily')}
              >
                Daily
              </button>
            </div>
          </div>
          
          <div className="pt-4 border-t border-neutral-200">
            <h3 className="text-lg font-medium text-neutral-900 mb-4">Additional Contributions (Optional)</h3>
            
            <div>
              <div className="flex justify-between mb-2">
                <label htmlFor="additional-contribution" className="text-sm font-medium text-neutral-700">
                  Contribution Amount (₹)
                </label>
                <span className="text-sm text-neutral-500">
                  {formatCurrency(additionalContribution)}
                </span>
              </div>
              <input 
                type="range" 
                id="additional-contribution"
                min="0" 
                max="100000" 
                step="500" 
                value={additionalContribution} 
                onChange={(e) => setAdditionalContribution(Number(e.target.value))}
                className="slider"
              />
              <div className="flex justify-between mt-1 text-xs text-neutral-500">
                <span>₹0</span>
                <span>₹1,00,000</span>
              </div>
            </div>
            
            <div className="mt-4">
              <label className="text-sm font-medium text-neutral-700 mb-2 block">
                Contribution Frequency
              </label>
              <div className="flex space-x-4">
                <button
                  className={`px-4 py-2 rounded-lg text-sm font-medium ${
                    contributionFrequency === 'monthly'
                      ? 'bg-[--primary-100] text-[--primary-800]'
                      : 'bg-neutral-100 text-neutral-600'
                  }`}
                  onClick={() => setContributionFrequency('monthly')}
                >
                  Monthly
                </button>
                <button
                  className={`px-4 py-2 rounded-lg text-sm font-medium ${
                    contributionFrequency === 'quarterly'
                      ? 'bg-[--primary-100] text-[--primary-800]'
                      : 'bg-neutral-100 text-neutral-600'
                  }`}
                  onClick={() => setContributionFrequency('quarterly')}
                >
                  Quarterly
                </button>
                <button
                  className={`px-4 py-2 rounded-lg text-sm font-medium ${
                    contributionFrequency === 'annually'
                      ? 'bg-[--primary-100] text-[--primary-800]'
                      : 'bg-neutral-100 text-neutral-600'
                  }`}
                  onClick={() => setContributionFrequency('annually')}
                >
                  Annually
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 p-6 bg-[--primary-50] rounded-lg border border-[--primary-100]">
          <h3 className="text-lg font-semibold text-[--primary-900] mb-4">Investment Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-lg shadow-sm">
              <p className="text-sm text-neutral-500 mb-1">Total Investment</p>
              <p className="text-xl font-bold text-neutral-900">{formatCurrency(totalInvestment)}</p>
            </div>
            <div className="p-4 bg-white rounded-lg shadow-sm">
              <p className="text-sm text-neutral-500 mb-1">Total Interest</p>
              <p className="text-xl font-bold text-[--success-600]">{formatCurrency(totalInterest)}</p>
            </div>
            <div className="p-4 bg-white rounded-lg shadow-sm">
              <p className="text-sm text-neutral-500 mb-1">Maturity Amount</p>
              <p className="text-xl font-bold text-[--success-600]">{formatCurrency(maturityAmount)}</p>
            </div>
          </div>
          <div className="mt-4 p-4 bg-[--accent-50] rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-neutral-500">Absolute Return</p>
                <p className="text-lg font-semibold text-neutral-900">
                  {((maturityAmount / totalInvestment - 1) * 100).toFixed(2)}%
                </p>
              </div>
              <div>
                <p className="text-sm text-neutral-500">Annualized Return (CAGR)</p>
                <p className="text-lg font-semibold text-neutral-900">
                  {(Math.pow(maturityAmount / totalInvestment, 1 / timePeriod) - 1) * 100 > 0 
                    ? ((Math.pow(maturityAmount / totalInvestment, 1 / timePeriod) - 1) * 100).toFixed(2) 
                    : 0}%
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold text-neutral-900 flex items-center">
            <PieChart className="w-5 h-5 mr-2 text-[--primary-600]" />
            Investment Breakup
          </h2>
          <div className="mt-4 h-64">
            <ResultChart 
              data={[
                { name: 'Principal', value: principal, color: '#3b82f6' },
                { name: 'Additional Contributions', value: totalInvestment - principal, color: '#8b5cf6' },
                { name: 'Interest', value: totalInterest, color: '#22c55e' }
              ]}
              centerText={`${formatCurrency(maturityAmount)}\nTotal Value`}
            />
          </div>
        </div>
        
        <div>
          <h2 className="text-xl font-semibold text-neutral-900 flex items-center">
            <Calculator className="w-5 h-5 mr-2 text-[--primary-600]" />
            Yearly Breakup
          </h2>
          <div className="mt-4 overflow-auto max-h-72 rounded-lg border border-neutral-200">
            <table className="min-w-full divide-y divide-neutral-200">
              <thead className="bg-neutral-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Year</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Investment (₹)</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Interest (₹)</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Balance (₹)</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-neutral-200">
                {yearlyBreakup.map((year, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-neutral-50'}>
                    <td className="px-4 py-2 text-sm text-neutral-900">{year.year}</td>
                    <td className="px-4 py-2 text-sm text-neutral-900">{formatCurrency(year.investment)}</td>
                    <td className="px-4 py-2 text-sm text-neutral-900">{formatCurrency(year.interest)}</td>
                    <td className="px-4 py-2 text-sm text-neutral-900">{formatCurrency(year.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="bg-neutral-50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold text-neutral-900 flex items-center mb-4">
            <Calculator className="w-5 h-5 mr-2 text-[--primary-600]" />
            Compound Interest Explained
          </h2>
          
          <div className="space-y-4">
            <div className="p-4 bg-white rounded-lg">
              <h3 className="text-lg font-medium text-neutral-900 mb-2">What is Compound Interest?</h3>
              <p className="text-sm text-neutral-600">
                Compound interest is the interest calculated on the initial principal and also on the accumulated interest over previous periods. It's essentially "interest on interest," which makes your money grow faster compared to simple interest.
              </p>
            </div>
            
            <div className="p-4 bg-white rounded-lg">
              <h3 className="text-lg font-medium text-neutral-900 mb-2">The Formula</h3>
              <p className="text-sm text-neutral-600 mb-2">
                The basic compound interest formula is:
              </p>
              <div className="bg-neutral-50 p-3 rounded-lg text-center font-medium text-neutral-800">
                A = P(1 + r/n)^(nt)
              </div>
              <p className="text-sm text-neutral-600 mt-2">
                Where:<br />
                A = Final amount<br />
                P = Principal (initial investment)<br />
                r = Annual interest rate (decimal)<br />
                n = Number of times interest is compounded per year<br />
                t = Time period in years
              </p>
            </div>
            
            <div className="p-4 bg-[--accent-50] rounded-lg">
              <h3 className="text-lg font-medium text-[--accent-900] mb-2">Power of Compounding</h3>
              <ul className="list-disc list-inside space-y-2 text-sm text-[--accent-700]">
                <li>The earlier you start investing, the more time your money has to grow</li>
                <li>Higher compounding frequency leads to slightly higher returns</li>
                <li>Regular additional contributions significantly boost your final corpus</li>
                <li>The Rule of 72: Divide 72 by your interest rate to estimate how many years it will take for your money to double</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};